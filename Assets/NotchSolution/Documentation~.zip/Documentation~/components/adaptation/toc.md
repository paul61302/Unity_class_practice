# [Aspect Ratio Adaptation](aspect-ratio-adaptation.md)
# [Safe Adaptation](safe-adaptation.md)